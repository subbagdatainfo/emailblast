<?php
/**
* Plugin Name: Tulisan Terbaru
* Plugin URI: http://kdesain.com
* Description: Menampilkan tulisan terbaru setiap hari dari konten multisite
* Version: 0.2
* Author: Ahmad Bagwi Rifai
* Author URI: https://instagram.com/ahmadbagwi
*/
defined( 'ABSPATH' ) or die( 'No script kiddies please!' );

function tulisan_terbaru_actions() {
     add_menu_page('Tulisan Terbaru', 'Tulisan terbaru', 'edit_pages', 'tulisan_terbaru', 'tulisan_terbaru_function', '', 87);
}
add_action('admin_menu', 'tulisan_terbaru_actions');

function tulisan_terbaru_function() { 
	echo "<h3>Menampilkan tulisan terbaru pada hari ini ".date('Y-m-d')."</h3>";

	$blogs = get_last_updated();

 	foreach ($blogs AS $blog)    {    
		switch_to_blog($blog["blog_id"]);
		$today = getdate();
		$args = array(
    	'post_type'         => 'post',
    	'post_status'       => 'publish',
    	'date_query'        => array(
    		array(
            'year'  => $today['year'],
            'month' => $today['mon'],
            'day'   => $today['mday']
        		)
    		)
		);
		$wpb_all_query = new WP_Query($args); ?>
		<?php if ( $wpb_all_query->have_posts() ) : ?>
	 
		<ul>
	    	<!-- the loop -->
	    	<?php while ( $wpb_all_query->have_posts() ) : $wpb_all_query->the_post(); ?>
	        <li><?php echo get_bloginfo( 'name' );?> <a href="<?php the_permalink(); ?>"><?php the_title(); get_bloginfo('name');?></a></li>
	    	<?php endwhile; ?>
	    	<!-- end of the loop -->
		</ul>
	 
	    <?php wp_reset_postdata(); ?>
	 
		<?php else : ?>
	    	<p><?php _e( 'Tidak ada posting hari ini' ); ?></p>
		<?php endif;
	  		restore_current_blog();
  	};
}; 